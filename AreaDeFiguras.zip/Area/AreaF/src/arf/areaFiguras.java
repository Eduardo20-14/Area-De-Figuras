//Eduardo Martinez Becerra
package arf;
import java.lang.Math;

/**
 *
 * Eduardo Martinez Becerra
 */
public class areaFiguras {
    
    public double areaRectangulo(double num1, double num2){
        return num1 * num2;
    }
    
    public double areaCirculo(double num1){
        return Math.pow(num1, 2) * 3.14159;
    }
    
    public double areaTriangulo(double num1, double num2){
        return (num1 * num2)/2;
    }
    
    public double areaCuadrado(double num1){
        return Math.pow(num1, 2);
    }
    
}
